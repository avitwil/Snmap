#!/bin/bash

sudo dpkg -i snmap_package.deb
echo "install complete"

clear

Snmap -h
