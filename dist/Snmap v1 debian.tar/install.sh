#!/bin/bash
echo "installing  Python3 - nmap ...."
sudo apt install python3-nmap
echo "Installing package..."
sudo dpkg -i Snmap.deb
